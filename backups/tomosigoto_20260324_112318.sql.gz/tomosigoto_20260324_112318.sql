--
-- PostgreSQL database dump
--

\restrict 335Tcf2sMywn6iec4IHaSnciSi2KibwexBcl6Z2KPiox3gxVsdoFynx6pLS6xw4

-- Dumped from database version 16.13
-- Dumped by pg_dump version 16.13

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: pgcrypto; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS pgcrypto WITH SCHEMA public;


--
-- Name: EXTENSION pgcrypto; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION pgcrypto IS 'cryptographic functions';


--
-- Name: set_updated_at(); Type: FUNCTION; Schema: public; Owner: tomosigoto
--

CREATE FUNCTION public.set_updated_at() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    NEW.updated_at = NOW();
    RETURN NEW;
END;
$$;


ALTER FUNCTION public.set_updated_at() OWNER TO tomosigoto;

--
-- Name: update_updated_at_column(); Type: FUNCTION; Schema: public; Owner: tomosigoto
--

CREATE FUNCTION public.update_updated_at_column() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    NEW.updated_at = NOW();
    RETURN NEW;
END;
$$;


ALTER FUNCTION public.update_updated_at_column() OWNER TO tomosigoto;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: account_setting_history; Type: TABLE; Schema: public; Owner: tomosigoto
--

CREATE TABLE public.account_setting_history (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    field_name text NOT NULL,
    old_value text,
    new_value text,
    changed_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.account_setting_history OWNER TO tomosigoto;

--
-- Name: contacts; Type: TABLE; Schema: public; Owner: tomosigoto
--

CREATE TABLE public.contacts (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    name text,
    category text NOT NULL,
    content text NOT NULL,
    status text DEFAULT 'pending'::text NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT contacts_category_check CHECK ((category = ANY (ARRAY['bug'::text, 'feature'::text, 'question'::text, 'other'::text]))),
    CONSTRAINT contacts_status_check CHECK ((status = ANY (ARRAY['pending'::text, 'in_progress'::text, 'resolved'::text, 'closed'::text])))
);


ALTER TABLE public.contacts OWNER TO tomosigoto;

--
-- Name: departments; Type: TABLE; Schema: public; Owner: tomosigoto
--

CREATE TABLE public.departments (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    department_code character varying(50),
    department_name character varying(100),
    campus character varying(50),
    is_active boolean,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.departments OWNER TO tomosigoto;

--
-- Name: favorites; Type: TABLE; Schema: public; Owner: tomosigoto
--

CREATE TABLE public.favorites (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    video_id uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.favorites OWNER TO tomosigoto;

--
-- Name: member_assignments; Type: TABLE; Schema: public; Owner: tomosigoto
--

CREATE TABLE public.member_assignments (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    part_id uuid NOT NULL,
    category character varying(10) NOT NULL,
    display_order integer DEFAULT 0,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT member_assignments_category_check CHECK (((category)::text = ANY ((ARRAY['utai'::character varying, 'mai'::character varying])::text[])))
);


ALTER TABLE public.member_assignments OWNER TO tomosigoto;

--
-- Name: parts; Type: TABLE; Schema: public; Owner: tomosigoto
--

CREATE TABLE public.parts (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    stage_id uuid NOT NULL,
    name character varying(255) NOT NULL,
    description text,
    status character varying(20) DEFAULT 'active'::character varying NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT parts_status_check CHECK (((status)::text = ANY ((ARRAY['active'::character varying, 'inactive'::character varying])::text[])))
);


ALTER TABLE public.parts OWNER TO tomosigoto;

--
-- Name: playlists; Type: TABLE; Schema: public; Owner: tomosigoto
--

CREATE TABLE public.playlists (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    title text NOT NULL,
    name text NOT NULL,
    year integer,
    thumbnail_url text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.playlists OWNER TO tomosigoto;

--
-- Name: practice_schedules; Type: TABLE; Schema: public; Owner: tomosigoto
--

CREATE TABLE public.practice_schedules (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    schedule_date date NOT NULL,
    start_time time without time zone NOT NULL,
    end_time time without time zone NOT NULL,
    division_count integer DEFAULT 1 NOT NULL,
    title character varying(100),
    description text,
    schedule_type character varying(20) NOT NULL,
    status character varying(20),
    stage_id uuid,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT practice_schedules_division_count_check CHECK ((division_count > 0))
);


ALTER TABLE public.practice_schedules OWNER TO tomosigoto;

--
-- Name: COLUMN practice_schedules.stage_id; Type: COMMENT; Schema: public; Owner: tomosigoto
--

COMMENT ON COLUMN public.practice_schedules.stage_id IS '舞台ID参照（この練習で扱う舞台）';


--
-- Name: practice_user_attendance; Type: TABLE; Schema: public; Owner: tomosigoto
--

CREATE TABLE public.practice_user_attendance (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    practice_schedule_id uuid NOT NULL,
    user_id uuid NOT NULL,
    status text NOT NULL,
    notes text,
    available_from time without time zone,
    available_to time without time zone,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT practice_user_attendance_status_check CHECK ((status = ANY (ARRAY['present'::text, 'absent'::text, 'late'::text, 'no_show'::text, 'undecided'::text])))
);


ALTER TABLE public.practice_user_attendance OWNER TO tomosigoto;

--
-- Name: refresh_tokens; Type: TABLE; Schema: public; Owner: tomosigoto
--

CREATE TABLE public.refresh_tokens (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    token text NOT NULL,
    expires_at timestamp with time zone NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.refresh_tokens OWNER TO tomosigoto;

--
-- Name: schedule_available_venues; Type: TABLE; Schema: public; Owner: tomosigoto
--

CREATE TABLE public.schedule_available_venues (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    schedule_id uuid NOT NULL,
    venue_id uuid NOT NULL,
    is_preferred boolean DEFAULT false,
    priority integer DEFAULT 0,
    notes text,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.schedule_available_venues OWNER TO tomosigoto;

--
-- Name: schedule_time_slots; Type: TABLE; Schema: public; Owner: tomosigoto
--

CREATE TABLE public.schedule_time_slots (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    schedule_id uuid NOT NULL,
    slot_order integer NOT NULL,
    start_time time without time zone NOT NULL,
    end_time time without time zone NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT schedule_time_slots_check CHECK ((start_time < end_time)),
    CONSTRAINT schedule_time_slots_slot_order_check CHECK ((slot_order > 0))
);


ALTER TABLE public.schedule_time_slots OWNER TO tomosigoto;

--
-- Name: session_instructors; Type: TABLE; Schema: public; Owner: tomosigoto
--

CREATE TABLE public.session_instructors (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    attendance_id uuid NOT NULL,
    schedule_id uuid NOT NULL,
    schedule_available_venue_id uuid,
    slot_order integer NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT session_instructors_slot_order_check CHECK ((slot_order > 0))
);


ALTER TABLE public.session_instructors OWNER TO tomosigoto;

--
-- Name: sessions; Type: TABLE; Schema: public; Owner: tomosigoto
--

CREATE TABLE public.sessions (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    schedule_id uuid NOT NULL,
    part_id uuid NOT NULL,
    title character varying(30),
    slot_order integer NOT NULL,
    schedule_available_venue_id uuid,
    priority integer DEFAULT 0,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT sessions_slot_order_check CHECK ((slot_order > 0))
);


ALTER TABLE public.sessions OWNER TO tomosigoto;

--
-- Name: stages; Type: TABLE; Schema: public; Owner: tomosigoto
--

CREATE TABLE public.stages (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    name character varying(255) NOT NULL,
    description text,
    performance_date date,
    status character varying(20) DEFAULT 'active'::character varying NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT stages_status_check CHECK (((status)::text = ANY ((ARRAY['active'::character varying, 'inactive'::character varying])::text[])))
);


ALTER TABLE public.stages OWNER TO tomosigoto;

--
-- Name: sub_playlists; Type: TABLE; Schema: public; Owner: tomosigoto
--

CREATE TABLE public.sub_playlists (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    playlist_id uuid NOT NULL,
    title text NOT NULL,
    recorded_date date,
    phase text,
    playlist_url text,
    thumbnail_url text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.sub_playlists OWNER TO tomosigoto;

--
-- Name: user_profiles; Type: TABLE; Schema: public; Owner: tomosigoto
--

CREATE TABLE public.user_profiles (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    student_id text NOT NULL,
    first_name_kanji text NOT NULL,
    first_name_katakana text NOT NULL,
    last_name_kanji text NOT NULL,
    last_name_katakana text NOT NULL,
    grade integer,
    department_id uuid NOT NULL,
    email text,
    avatar_url text,
    preferences jsonb,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.user_profiles OWNER TO tomosigoto;

--
-- Name: COLUMN user_profiles.email; Type: COMMENT; Schema: public; Owner: tomosigoto
--

COMMENT ON COLUMN public.user_profiles.email IS 'メールアドレス（users テーブルと同期）';


--
-- Name: user_roles; Type: TABLE; Schema: public; Owner: tomosigoto
--

CREATE TABLE public.user_roles (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid,
    role_type text NOT NULL,
    is_visible_to_general boolean DEFAULT false,
    is_instructor boolean DEFAULT false,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.user_roles OWNER TO tomosigoto;

--
-- Name: users; Type: TABLE; Schema: public; Owner: tomosigoto
--

CREATE TABLE public.users (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    email text NOT NULL,
    encrypted_password text NOT NULL,
    is_verified boolean DEFAULT false,
    verify_token text,
    verify_token_expires timestamp with time zone,
    raw_user_meta_data jsonb DEFAULT '{}'::jsonb,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    last_sign_in_at timestamp with time zone
);


ALTER TABLE public.users OWNER TO tomosigoto;

--
-- Name: venues; Type: TABLE; Schema: public; Owner: tomosigoto
--

CREATE TABLE public.venues (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    name text NOT NULL,
    code text NOT NULL,
    campus text NOT NULL,
    address text NOT NULL,
    latitude double precision NOT NULL,
    longitude double precision NOT NULL,
    can_mai boolean NOT NULL,
    capacity integer NOT NULL,
    desk integer,
    chair integer,
    description text,
    is_active boolean NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.venues OWNER TO tomosigoto;

--
-- Name: videos; Type: TABLE; Schema: public; Owner: tomosigoto
--

CREATE TABLE public.videos (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    sub_playlist_id uuid NOT NULL,
    title text NOT NULL,
    video_url text NOT NULL,
    recorded_date date,
    thumbnail_url text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.videos OWNER TO tomosigoto;

--
-- Data for Name: account_setting_history; Type: TABLE DATA; Schema: public; Owner: tomosigoto
--

COPY public.account_setting_history (id, user_id, field_name, old_value, new_value, changed_at) FROM stdin;
\.


--
-- Data for Name: contacts; Type: TABLE DATA; Schema: public; Owner: tomosigoto
--

COPY public.contacts (id, user_id, name, category, content, status, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: departments; Type: TABLE DATA; Schema: public; Owner: tomosigoto
--

COPY public.departments (id, department_code, department_name, campus, is_active, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: favorites; Type: TABLE DATA; Schema: public; Owner: tomosigoto
--

COPY public.favorites (id, user_id, video_id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: member_assignments; Type: TABLE DATA; Schema: public; Owner: tomosigoto
--

COPY public.member_assignments (id, user_id, part_id, category, display_order, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: parts; Type: TABLE DATA; Schema: public; Owner: tomosigoto
--

COPY public.parts (id, stage_id, name, description, status, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: playlists; Type: TABLE DATA; Schema: public; Owner: tomosigoto
--

COPY public.playlists (id, title, name, year, thumbnail_url, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: practice_schedules; Type: TABLE DATA; Schema: public; Owner: tomosigoto
--

COPY public.practice_schedules (id, schedule_date, start_time, end_time, division_count, title, description, schedule_type, status, stage_id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: practice_user_attendance; Type: TABLE DATA; Schema: public; Owner: tomosigoto
--

COPY public.practice_user_attendance (id, practice_schedule_id, user_id, status, notes, available_from, available_to, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: refresh_tokens; Type: TABLE DATA; Schema: public; Owner: tomosigoto
--

COPY public.refresh_tokens (id, user_id, token, expires_at, created_at) FROM stdin;
7eae5285-e020-491d-aa7c-d349149a4580	747fd233-6755-4205-b29b-a2847a7fff50	6a1e4f4f6276cbcdb433e77d0833012be3b4cdbc9e5fd2615736a1e62f2187b9	2026-04-23 01:52:26.745301+00	2026-03-24 01:52:26.743094+00
7a083bae-dacb-4ed3-ad7b-322750a7d03e	747fd233-6755-4205-b29b-a2847a7fff50	d46c0c82cdf8331aff767349b98338147f0c542b3ad1029f82c4dac0f7151354	2026-04-23 01:53:11.833367+00	2026-03-24 01:53:11.832313+00
\.


--
-- Data for Name: schedule_available_venues; Type: TABLE DATA; Schema: public; Owner: tomosigoto
--

COPY public.schedule_available_venues (id, schedule_id, venue_id, is_preferred, priority, notes, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: schedule_time_slots; Type: TABLE DATA; Schema: public; Owner: tomosigoto
--

COPY public.schedule_time_slots (id, schedule_id, slot_order, start_time, end_time, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: session_instructors; Type: TABLE DATA; Schema: public; Owner: tomosigoto
--

COPY public.session_instructors (id, attendance_id, schedule_id, schedule_available_venue_id, slot_order, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: sessions; Type: TABLE DATA; Schema: public; Owner: tomosigoto
--

COPY public.sessions (id, schedule_id, part_id, title, slot_order, schedule_available_venue_id, priority, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: stages; Type: TABLE DATA; Schema: public; Owner: tomosigoto
--

COPY public.stages (id, name, description, performance_date, status, created_at, updated_at) FROM stdin;
118ea2b4-54c8-4f5f-ba44-c282bf5c73e1	テストステージ	テスト用	\N	active	2026-03-24 01:53:22.553731+00	2026-03-24 01:53:22.553731+00
\.


--
-- Data for Name: sub_playlists; Type: TABLE DATA; Schema: public; Owner: tomosigoto
--

COPY public.sub_playlists (id, playlist_id, title, recorded_date, phase, playlist_url, thumbnail_url, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: user_profiles; Type: TABLE DATA; Schema: public; Owner: tomosigoto
--

COPY public.user_profiles (id, user_id, student_id, first_name_kanji, first_name_katakana, last_name_kanji, last_name_katakana, grade, department_id, email, avatar_url, preferences, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: user_roles; Type: TABLE DATA; Schema: public; Owner: tomosigoto
--

COPY public.user_roles (id, user_id, role_type, is_visible_to_general, is_instructor, created_at, updated_at) FROM stdin;
e7194035-c54c-41f2-8bc0-d49c53e6c848	747fd233-6755-4205-b29b-a2847a7fff50	admin	t	t	2026-03-24 01:52:55.622423+00	2026-03-24 01:52:55.622423+00
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: tomosigoto
--

COPY public.users (id, email, encrypted_password, is_verified, verify_token, verify_token_expires, raw_user_meta_data, created_at, updated_at, last_sign_in_at) FROM stdin;
747fd233-6755-4205-b29b-a2847a7fff50	test@example.com	$2b$12$zG8IqpSeYJEpCh7.AdrnA.EgFXxEU7xr7rV7FQQU0uLBCrpNi2N6G	t	\N	\N	{}	2026-03-24 01:52:18.047995+00	2026-03-24 01:52:30.652041+00	2026-03-24 01:52:30.652041+00
\.


--
-- Data for Name: venues; Type: TABLE DATA; Schema: public; Owner: tomosigoto
--

COPY public.venues (id, name, code, campus, address, latitude, longitude, can_mai, capacity, desk, chair, description, is_active, created_at, updated_at) FROM stdin;
3fb9eca4-0a2c-4077-a191-8f4a0195e3a8	テスト会場	V001	今出川	京都市	35	135	f	100	\N	\N	\N	t	2026-03-24 01:53:22.456988+00	2026-03-24 01:53:22.456988+00
\.


--
-- Data for Name: videos; Type: TABLE DATA; Schema: public; Owner: tomosigoto
--

COPY public.videos (id, sub_playlist_id, title, video_url, recorded_date, thumbnail_url, created_at, updated_at) FROM stdin;
\.


--
-- Name: account_setting_history account_setting_history_pkey; Type: CONSTRAINT; Schema: public; Owner: tomosigoto
--

ALTER TABLE ONLY public.account_setting_history
    ADD CONSTRAINT account_setting_history_pkey PRIMARY KEY (id);


--
-- Name: contacts contacts_pkey; Type: CONSTRAINT; Schema: public; Owner: tomosigoto
--

ALTER TABLE ONLY public.contacts
    ADD CONSTRAINT contacts_pkey PRIMARY KEY (id);


--
-- Name: departments departments_department_code_key; Type: CONSTRAINT; Schema: public; Owner: tomosigoto
--

ALTER TABLE ONLY public.departments
    ADD CONSTRAINT departments_department_code_key UNIQUE (department_code);


--
-- Name: departments departments_pkey; Type: CONSTRAINT; Schema: public; Owner: tomosigoto
--

ALTER TABLE ONLY public.departments
    ADD CONSTRAINT departments_pkey PRIMARY KEY (id);


--
-- Name: favorites favorites_pkey; Type: CONSTRAINT; Schema: public; Owner: tomosigoto
--

ALTER TABLE ONLY public.favorites
    ADD CONSTRAINT favorites_pkey PRIMARY KEY (id);


--
-- Name: favorites favorites_unique; Type: CONSTRAINT; Schema: public; Owner: tomosigoto
--

ALTER TABLE ONLY public.favorites
    ADD CONSTRAINT favorites_unique UNIQUE (user_id, video_id);


--
-- Name: member_assignments member_assignments_pkey; Type: CONSTRAINT; Schema: public; Owner: tomosigoto
--

ALTER TABLE ONLY public.member_assignments
    ADD CONSTRAINT member_assignments_pkey PRIMARY KEY (id);


--
-- Name: member_assignments member_assignments_user_id_part_id_key; Type: CONSTRAINT; Schema: public; Owner: tomosigoto
--

ALTER TABLE ONLY public.member_assignments
    ADD CONSTRAINT member_assignments_user_id_part_id_key UNIQUE (user_id, part_id);


--
-- Name: parts parts_pkey; Type: CONSTRAINT; Schema: public; Owner: tomosigoto
--

ALTER TABLE ONLY public.parts
    ADD CONSTRAINT parts_pkey PRIMARY KEY (id);


--
-- Name: playlists playlists_pkey; Type: CONSTRAINT; Schema: public; Owner: tomosigoto
--

ALTER TABLE ONLY public.playlists
    ADD CONSTRAINT playlists_pkey PRIMARY KEY (id);


--
-- Name: practice_schedules practice_schedules_pkey; Type: CONSTRAINT; Schema: public; Owner: tomosigoto
--

ALTER TABLE ONLY public.practice_schedules
    ADD CONSTRAINT practice_schedules_pkey PRIMARY KEY (id);


--
-- Name: practice_user_attendance practice_user_attendance_pkey; Type: CONSTRAINT; Schema: public; Owner: tomosigoto
--

ALTER TABLE ONLY public.practice_user_attendance
    ADD CONSTRAINT practice_user_attendance_pkey PRIMARY KEY (id);


--
-- Name: practice_user_attendance practice_user_attendance_practice_schedule_id_user_id_key; Type: CONSTRAINT; Schema: public; Owner: tomosigoto
--

ALTER TABLE ONLY public.practice_user_attendance
    ADD CONSTRAINT practice_user_attendance_practice_schedule_id_user_id_key UNIQUE (practice_schedule_id, user_id);


--
-- Name: refresh_tokens refresh_tokens_pkey; Type: CONSTRAINT; Schema: public; Owner: tomosigoto
--

ALTER TABLE ONLY public.refresh_tokens
    ADD CONSTRAINT refresh_tokens_pkey PRIMARY KEY (id);


--
-- Name: refresh_tokens refresh_tokens_token_key; Type: CONSTRAINT; Schema: public; Owner: tomosigoto
--

ALTER TABLE ONLY public.refresh_tokens
    ADD CONSTRAINT refresh_tokens_token_key UNIQUE (token);


--
-- Name: schedule_available_venues schedule_available_venues_pkey; Type: CONSTRAINT; Schema: public; Owner: tomosigoto
--

ALTER TABLE ONLY public.schedule_available_venues
    ADD CONSTRAINT schedule_available_venues_pkey PRIMARY KEY (id);


--
-- Name: schedule_time_slots schedule_time_slots_pkey; Type: CONSTRAINT; Schema: public; Owner: tomosigoto
--

ALTER TABLE ONLY public.schedule_time_slots
    ADD CONSTRAINT schedule_time_slots_pkey PRIMARY KEY (id);


--
-- Name: schedule_time_slots schedule_time_slots_schedule_id_slot_order_key; Type: CONSTRAINT; Schema: public; Owner: tomosigoto
--

ALTER TABLE ONLY public.schedule_time_slots
    ADD CONSTRAINT schedule_time_slots_schedule_id_slot_order_key UNIQUE (schedule_id, slot_order);


--
-- Name: session_instructors session_instructors_pkey; Type: CONSTRAINT; Schema: public; Owner: tomosigoto
--

ALTER TABLE ONLY public.session_instructors
    ADD CONSTRAINT session_instructors_pkey PRIMARY KEY (id);


--
-- Name: sessions sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: tomosigoto
--

ALTER TABLE ONLY public.sessions
    ADD CONSTRAINT sessions_pkey PRIMARY KEY (id);


--
-- Name: sessions sessions_schedule_venue_slot_unique; Type: CONSTRAINT; Schema: public; Owner: tomosigoto
--

ALTER TABLE ONLY public.sessions
    ADD CONSTRAINT sessions_schedule_venue_slot_unique UNIQUE (schedule_id, schedule_available_venue_id, slot_order);


--
-- Name: stages stages_pkey; Type: CONSTRAINT; Schema: public; Owner: tomosigoto
--

ALTER TABLE ONLY public.stages
    ADD CONSTRAINT stages_pkey PRIMARY KEY (id);


--
-- Name: sub_playlists sub_playlists_pkey; Type: CONSTRAINT; Schema: public; Owner: tomosigoto
--

ALTER TABLE ONLY public.sub_playlists
    ADD CONSTRAINT sub_playlists_pkey PRIMARY KEY (id);


--
-- Name: user_profiles user_profiles_pkey; Type: CONSTRAINT; Schema: public; Owner: tomosigoto
--

ALTER TABLE ONLY public.user_profiles
    ADD CONSTRAINT user_profiles_pkey PRIMARY KEY (id);


--
-- Name: user_profiles user_profiles_student_id_key; Type: CONSTRAINT; Schema: public; Owner: tomosigoto
--

ALTER TABLE ONLY public.user_profiles
    ADD CONSTRAINT user_profiles_student_id_key UNIQUE (student_id);


--
-- Name: user_roles user_roles_pkey; Type: CONSTRAINT; Schema: public; Owner: tomosigoto
--

ALTER TABLE ONLY public.user_roles
    ADD CONSTRAINT user_roles_pkey PRIMARY KEY (id);


--
-- Name: users users_email_key; Type: CONSTRAINT; Schema: public; Owner: tomosigoto
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_email_key UNIQUE (email);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: tomosigoto
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: venues venues_code_key; Type: CONSTRAINT; Schema: public; Owner: tomosigoto
--

ALTER TABLE ONLY public.venues
    ADD CONSTRAINT venues_code_key UNIQUE (code);


--
-- Name: venues venues_pkey; Type: CONSTRAINT; Schema: public; Owner: tomosigoto
--

ALTER TABLE ONLY public.venues
    ADD CONSTRAINT venues_pkey PRIMARY KEY (id);


--
-- Name: videos videos_pkey; Type: CONSTRAINT; Schema: public; Owner: tomosigoto
--

ALTER TABLE ONLY public.videos
    ADD CONSTRAINT videos_pkey PRIMARY KEY (id);


--
-- Name: idx_account_setting_history_changed_at; Type: INDEX; Schema: public; Owner: tomosigoto
--

CREATE INDEX idx_account_setting_history_changed_at ON public.account_setting_history USING btree (changed_at DESC);


--
-- Name: idx_account_setting_history_user_id; Type: INDEX; Schema: public; Owner: tomosigoto
--

CREATE INDEX idx_account_setting_history_user_id ON public.account_setting_history USING btree (user_id);


--
-- Name: idx_contacts_category; Type: INDEX; Schema: public; Owner: tomosigoto
--

CREATE INDEX idx_contacts_category ON public.contacts USING btree (category);


--
-- Name: idx_contacts_created_at; Type: INDEX; Schema: public; Owner: tomosigoto
--

CREATE INDEX idx_contacts_created_at ON public.contacts USING btree (created_at);


--
-- Name: idx_contacts_status; Type: INDEX; Schema: public; Owner: tomosigoto
--

CREATE INDEX idx_contacts_status ON public.contacts USING btree (status);


--
-- Name: idx_contacts_user_id; Type: INDEX; Schema: public; Owner: tomosigoto
--

CREATE INDEX idx_contacts_user_id ON public.contacts USING btree (user_id);


--
-- Name: idx_favorites_user_id; Type: INDEX; Schema: public; Owner: tomosigoto
--

CREATE INDEX idx_favorites_user_id ON public.favorites USING btree (user_id);


--
-- Name: idx_favorites_video_id; Type: INDEX; Schema: public; Owner: tomosigoto
--

CREATE INDEX idx_favorites_video_id ON public.favorites USING btree (video_id);


--
-- Name: idx_member_assignments_category; Type: INDEX; Schema: public; Owner: tomosigoto
--

CREATE INDEX idx_member_assignments_category ON public.member_assignments USING btree (category);


--
-- Name: idx_member_assignments_part_id; Type: INDEX; Schema: public; Owner: tomosigoto
--

CREATE INDEX idx_member_assignments_part_id ON public.member_assignments USING btree (part_id);


--
-- Name: idx_member_assignments_user_id; Type: INDEX; Schema: public; Owner: tomosigoto
--

CREATE INDEX idx_member_assignments_user_id ON public.member_assignments USING btree (user_id);


--
-- Name: idx_parts_stage_id; Type: INDEX; Schema: public; Owner: tomosigoto
--

CREATE INDEX idx_parts_stage_id ON public.parts USING btree (stage_id);


--
-- Name: idx_parts_status; Type: INDEX; Schema: public; Owner: tomosigoto
--

CREATE INDEX idx_parts_status ON public.parts USING btree (status);


--
-- Name: idx_playlists_name; Type: INDEX; Schema: public; Owner: tomosigoto
--

CREATE INDEX idx_playlists_name ON public.playlists USING btree (name);


--
-- Name: idx_playlists_year; Type: INDEX; Schema: public; Owner: tomosigoto
--

CREATE INDEX idx_playlists_year ON public.playlists USING btree (year);


--
-- Name: idx_practice_schedules_date; Type: INDEX; Schema: public; Owner: tomosigoto
--

CREATE INDEX idx_practice_schedules_date ON public.practice_schedules USING btree (schedule_date);


--
-- Name: idx_practice_schedules_stage_id; Type: INDEX; Schema: public; Owner: tomosigoto
--

CREATE INDEX idx_practice_schedules_stage_id ON public.practice_schedules USING btree (stage_id);


--
-- Name: idx_practice_schedules_status; Type: INDEX; Schema: public; Owner: tomosigoto
--

CREATE INDEX idx_practice_schedules_status ON public.practice_schedules USING btree (status);


--
-- Name: idx_practice_user_attendance_practice_schedule_id; Type: INDEX; Schema: public; Owner: tomosigoto
--

CREATE INDEX idx_practice_user_attendance_practice_schedule_id ON public.practice_user_attendance USING btree (practice_schedule_id);


--
-- Name: idx_practice_user_attendance_status; Type: INDEX; Schema: public; Owner: tomosigoto
--

CREATE INDEX idx_practice_user_attendance_status ON public.practice_user_attendance USING btree (status);


--
-- Name: idx_practice_user_attendance_user_id; Type: INDEX; Schema: public; Owner: tomosigoto
--

CREATE INDEX idx_practice_user_attendance_user_id ON public.practice_user_attendance USING btree (user_id);


--
-- Name: idx_pua_schedule_user_status; Type: INDEX; Schema: public; Owner: tomosigoto
--

CREATE INDEX idx_pua_schedule_user_status ON public.practice_user_attendance USING btree (practice_schedule_id, user_id, status);


--
-- Name: idx_refresh_tokens_token; Type: INDEX; Schema: public; Owner: tomosigoto
--

CREATE INDEX idx_refresh_tokens_token ON public.refresh_tokens USING btree (token);


--
-- Name: idx_refresh_tokens_user_id; Type: INDEX; Schema: public; Owner: tomosigoto
--

CREATE INDEX idx_refresh_tokens_user_id ON public.refresh_tokens USING btree (user_id);


--
-- Name: idx_schedule_available_venues_schedule_id; Type: INDEX; Schema: public; Owner: tomosigoto
--

CREATE INDEX idx_schedule_available_venues_schedule_id ON public.schedule_available_venues USING btree (schedule_id);


--
-- Name: idx_schedule_time_slots_schedule_id; Type: INDEX; Schema: public; Owner: tomosigoto
--

CREATE INDEX idx_schedule_time_slots_schedule_id ON public.schedule_time_slots USING btree (schedule_id);


--
-- Name: idx_schedule_time_slots_slot_order; Type: INDEX; Schema: public; Owner: tomosigoto
--

CREATE INDEX idx_schedule_time_slots_slot_order ON public.schedule_time_slots USING btree (slot_order);


--
-- Name: idx_schedule_time_slots_start_time; Type: INDEX; Schema: public; Owner: tomosigoto
--

CREATE INDEX idx_schedule_time_slots_start_time ON public.schedule_time_slots USING btree (start_time);


--
-- Name: idx_session_instructors_attendance_id; Type: INDEX; Schema: public; Owner: tomosigoto
--

CREATE INDEX idx_session_instructors_attendance_id ON public.session_instructors USING btree (attendance_id);


--
-- Name: idx_session_instructors_schedule_id; Type: INDEX; Schema: public; Owner: tomosigoto
--

CREATE INDEX idx_session_instructors_schedule_id ON public.session_instructors USING btree (schedule_id);


--
-- Name: idx_sessions_part_id; Type: INDEX; Schema: public; Owner: tomosigoto
--

CREATE INDEX idx_sessions_part_id ON public.sessions USING btree (part_id);


--
-- Name: idx_sessions_schedule_available_venue_id; Type: INDEX; Schema: public; Owner: tomosigoto
--

CREATE INDEX idx_sessions_schedule_available_venue_id ON public.sessions USING btree (schedule_available_venue_id);


--
-- Name: idx_sessions_schedule_id; Type: INDEX; Schema: public; Owner: tomosigoto
--

CREATE INDEX idx_sessions_schedule_id ON public.sessions USING btree (schedule_id);


--
-- Name: idx_sessions_slot_order; Type: INDEX; Schema: public; Owner: tomosigoto
--

CREATE INDEX idx_sessions_slot_order ON public.sessions USING btree (slot_order);


--
-- Name: idx_stages_performance_date; Type: INDEX; Schema: public; Owner: tomosigoto
--

CREATE INDEX idx_stages_performance_date ON public.stages USING btree (performance_date);


--
-- Name: idx_stages_status; Type: INDEX; Schema: public; Owner: tomosigoto
--

CREATE INDEX idx_stages_status ON public.stages USING btree (status);


--
-- Name: idx_sub_playlists_phase; Type: INDEX; Schema: public; Owner: tomosigoto
--

CREATE INDEX idx_sub_playlists_phase ON public.sub_playlists USING btree (phase);


--
-- Name: idx_sub_playlists_playlist_id; Type: INDEX; Schema: public; Owner: tomosigoto
--

CREATE INDEX idx_sub_playlists_playlist_id ON public.sub_playlists USING btree (playlist_id);


--
-- Name: idx_user_profiles_email; Type: INDEX; Schema: public; Owner: tomosigoto
--

CREATE INDEX idx_user_profiles_email ON public.user_profiles USING btree (email);


--
-- Name: idx_user_profiles_user_id; Type: INDEX; Schema: public; Owner: tomosigoto
--

CREATE INDEX idx_user_profiles_user_id ON public.user_profiles USING btree (user_id);


--
-- Name: idx_user_roles_user_id; Type: INDEX; Schema: public; Owner: tomosigoto
--

CREATE INDEX idx_user_roles_user_id ON public.user_roles USING btree (user_id);


--
-- Name: idx_users_email; Type: INDEX; Schema: public; Owner: tomosigoto
--

CREATE INDEX idx_users_email ON public.users USING btree (email);


--
-- Name: idx_videos_sub_playlist_id; Type: INDEX; Schema: public; Owner: tomosigoto
--

CREATE INDEX idx_videos_sub_playlist_id ON public.videos USING btree (sub_playlist_id);


--
-- Name: favorites set_updated_at_favorites; Type: TRIGGER; Schema: public; Owner: tomosigoto
--

CREATE TRIGGER set_updated_at_favorites BEFORE UPDATE ON public.favorites FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();


--
-- Name: playlists set_updated_at_playlists; Type: TRIGGER; Schema: public; Owner: tomosigoto
--

CREATE TRIGGER set_updated_at_playlists BEFORE UPDATE ON public.playlists FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();


--
-- Name: sub_playlists set_updated_at_sub_playlists; Type: TRIGGER; Schema: public; Owner: tomosigoto
--

CREATE TRIGGER set_updated_at_sub_playlists BEFORE UPDATE ON public.sub_playlists FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();


--
-- Name: videos set_updated_at_videos; Type: TRIGGER; Schema: public; Owner: tomosigoto
--

CREATE TRIGGER set_updated_at_videos BEFORE UPDATE ON public.videos FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();


--
-- Name: practice_schedules trg_u_practice_schedules; Type: TRIGGER; Schema: public; Owner: tomosigoto
--

CREATE TRIGGER trg_u_practice_schedules BEFORE UPDATE ON public.practice_schedules FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: practice_user_attendance trg_u_practice_user_attendance; Type: TRIGGER; Schema: public; Owner: tomosigoto
--

CREATE TRIGGER trg_u_practice_user_attendance BEFORE UPDATE ON public.practice_user_attendance FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: schedule_available_venues trg_u_schedule_available_venues; Type: TRIGGER; Schema: public; Owner: tomosigoto
--

CREATE TRIGGER trg_u_schedule_available_venues BEFORE UPDATE ON public.schedule_available_venues FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: schedule_time_slots trg_u_schedule_time_slots; Type: TRIGGER; Schema: public; Owner: tomosigoto
--

CREATE TRIGGER trg_u_schedule_time_slots BEFORE UPDATE ON public.schedule_time_slots FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: session_instructors trg_u_session_instructors; Type: TRIGGER; Schema: public; Owner: tomosigoto
--

CREATE TRIGGER trg_u_session_instructors BEFORE UPDATE ON public.session_instructors FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: sessions trg_u_sessions; Type: TRIGGER; Schema: public; Owner: tomosigoto
--

CREATE TRIGGER trg_u_sessions BEFORE UPDATE ON public.sessions FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: contacts update_contacts_updated_at; Type: TRIGGER; Schema: public; Owner: tomosigoto
--

CREATE TRIGGER update_contacts_updated_at BEFORE UPDATE ON public.contacts FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: member_assignments update_member_assignments_updated_at; Type: TRIGGER; Schema: public; Owner: tomosigoto
--

CREATE TRIGGER update_member_assignments_updated_at BEFORE UPDATE ON public.member_assignments FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: parts update_parts_updated_at; Type: TRIGGER; Schema: public; Owner: tomosigoto
--

CREATE TRIGGER update_parts_updated_at BEFORE UPDATE ON public.parts FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: stages update_stages_updated_at; Type: TRIGGER; Schema: public; Owner: tomosigoto
--

CREATE TRIGGER update_stages_updated_at BEFORE UPDATE ON public.stages FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: user_profiles update_user_profiles_updated_at; Type: TRIGGER; Schema: public; Owner: tomosigoto
--

CREATE TRIGGER update_user_profiles_updated_at BEFORE UPDATE ON public.user_profiles FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: user_roles update_user_roles_updated_at; Type: TRIGGER; Schema: public; Owner: tomosigoto
--

CREATE TRIGGER update_user_roles_updated_at BEFORE UPDATE ON public.user_roles FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: users update_users_updated_at; Type: TRIGGER; Schema: public; Owner: tomosigoto
--

CREATE TRIGGER update_users_updated_at BEFORE UPDATE ON public.users FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: venues update_venues_updated_at; Type: TRIGGER; Schema: public; Owner: tomosigoto
--

CREATE TRIGGER update_venues_updated_at BEFORE UPDATE ON public.venues FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: account_setting_history account_setting_history_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: tomosigoto
--

ALTER TABLE ONLY public.account_setting_history
    ADD CONSTRAINT account_setting_history_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: contacts contacts_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: tomosigoto
--

ALTER TABLE ONLY public.contacts
    ADD CONSTRAINT contacts_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: favorites favorites_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: tomosigoto
--

ALTER TABLE ONLY public.favorites
    ADD CONSTRAINT favorites_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: favorites favorites_video_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: tomosigoto
--

ALTER TABLE ONLY public.favorites
    ADD CONSTRAINT favorites_video_id_fkey FOREIGN KEY (video_id) REFERENCES public.videos(id) ON DELETE CASCADE;


--
-- Name: member_assignments member_assignments_part_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: tomosigoto
--

ALTER TABLE ONLY public.member_assignments
    ADD CONSTRAINT member_assignments_part_id_fkey FOREIGN KEY (part_id) REFERENCES public.parts(id) ON DELETE CASCADE;


--
-- Name: member_assignments member_assignments_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: tomosigoto
--

ALTER TABLE ONLY public.member_assignments
    ADD CONSTRAINT member_assignments_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: parts parts_stage_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: tomosigoto
--

ALTER TABLE ONLY public.parts
    ADD CONSTRAINT parts_stage_id_fkey FOREIGN KEY (stage_id) REFERENCES public.stages(id) ON DELETE CASCADE;


--
-- Name: practice_schedules practice_schedules_stage_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: tomosigoto
--

ALTER TABLE ONLY public.practice_schedules
    ADD CONSTRAINT practice_schedules_stage_id_fkey FOREIGN KEY (stage_id) REFERENCES public.stages(id) ON DELETE SET NULL;


--
-- Name: practice_user_attendance practice_user_attendance_practice_schedule_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: tomosigoto
--

ALTER TABLE ONLY public.practice_user_attendance
    ADD CONSTRAINT practice_user_attendance_practice_schedule_id_fkey FOREIGN KEY (practice_schedule_id) REFERENCES public.practice_schedules(id) ON DELETE CASCADE;


--
-- Name: practice_user_attendance practice_user_attendance_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: tomosigoto
--

ALTER TABLE ONLY public.practice_user_attendance
    ADD CONSTRAINT practice_user_attendance_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: refresh_tokens refresh_tokens_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: tomosigoto
--

ALTER TABLE ONLY public.refresh_tokens
    ADD CONSTRAINT refresh_tokens_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: schedule_available_venues schedule_available_venues_schedule_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: tomosigoto
--

ALTER TABLE ONLY public.schedule_available_venues
    ADD CONSTRAINT schedule_available_venues_schedule_id_fkey FOREIGN KEY (schedule_id) REFERENCES public.practice_schedules(id) ON DELETE CASCADE;


--
-- Name: schedule_available_venues schedule_available_venues_venue_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: tomosigoto
--

ALTER TABLE ONLY public.schedule_available_venues
    ADD CONSTRAINT schedule_available_venues_venue_id_fkey FOREIGN KEY (venue_id) REFERENCES public.venues(id) ON DELETE CASCADE;


--
-- Name: schedule_time_slots schedule_time_slots_schedule_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: tomosigoto
--

ALTER TABLE ONLY public.schedule_time_slots
    ADD CONSTRAINT schedule_time_slots_schedule_id_fkey FOREIGN KEY (schedule_id) REFERENCES public.practice_schedules(id) ON DELETE CASCADE;


--
-- Name: session_instructors session_instructors_attendance_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: tomosigoto
--

ALTER TABLE ONLY public.session_instructors
    ADD CONSTRAINT session_instructors_attendance_id_fkey FOREIGN KEY (attendance_id) REFERENCES public.practice_user_attendance(id) ON DELETE RESTRICT;


--
-- Name: session_instructors session_instructors_schedule_available_venue_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: tomosigoto
--

ALTER TABLE ONLY public.session_instructors
    ADD CONSTRAINT session_instructors_schedule_available_venue_id_fkey FOREIGN KEY (schedule_available_venue_id) REFERENCES public.schedule_available_venues(id) ON DELETE SET NULL;


--
-- Name: session_instructors session_instructors_schedule_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: tomosigoto
--

ALTER TABLE ONLY public.session_instructors
    ADD CONSTRAINT session_instructors_schedule_id_fkey FOREIGN KEY (schedule_id) REFERENCES public.practice_schedules(id) ON DELETE CASCADE;


--
-- Name: sessions sessions_part_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: tomosigoto
--

ALTER TABLE ONLY public.sessions
    ADD CONSTRAINT sessions_part_id_fkey FOREIGN KEY (part_id) REFERENCES public.parts(id) ON DELETE CASCADE;


--
-- Name: sessions sessions_schedule_available_venue_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: tomosigoto
--

ALTER TABLE ONLY public.sessions
    ADD CONSTRAINT sessions_schedule_available_venue_id_fkey FOREIGN KEY (schedule_available_venue_id) REFERENCES public.schedule_available_venues(id) ON DELETE SET NULL;


--
-- Name: sessions sessions_schedule_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: tomosigoto
--

ALTER TABLE ONLY public.sessions
    ADD CONSTRAINT sessions_schedule_id_fkey FOREIGN KEY (schedule_id) REFERENCES public.practice_schedules(id) ON DELETE CASCADE;


--
-- Name: sub_playlists sub_playlists_playlist_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: tomosigoto
--

ALTER TABLE ONLY public.sub_playlists
    ADD CONSTRAINT sub_playlists_playlist_id_fkey FOREIGN KEY (playlist_id) REFERENCES public.playlists(id) ON DELETE CASCADE;


--
-- Name: user_profiles user_profiles_department_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: tomosigoto
--

ALTER TABLE ONLY public.user_profiles
    ADD CONSTRAINT user_profiles_department_id_fkey FOREIGN KEY (department_id) REFERENCES public.departments(id);


--
-- Name: user_profiles user_profiles_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: tomosigoto
--

ALTER TABLE ONLY public.user_profiles
    ADD CONSTRAINT user_profiles_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: user_roles user_roles_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: tomosigoto
--

ALTER TABLE ONLY public.user_roles
    ADD CONSTRAINT user_roles_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: videos videos_sub_playlist_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: tomosigoto
--

ALTER TABLE ONLY public.videos
    ADD CONSTRAINT videos_sub_playlist_id_fkey FOREIGN KEY (sub_playlist_id) REFERENCES public.sub_playlists(id) ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

\unrestrict 335Tcf2sMywn6iec4IHaSnciSi2KibwexBcl6Z2KPiox3gxVsdoFynx6pLS6xw4

